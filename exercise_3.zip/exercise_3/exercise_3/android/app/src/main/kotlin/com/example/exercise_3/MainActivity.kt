package com.example.exercise_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
