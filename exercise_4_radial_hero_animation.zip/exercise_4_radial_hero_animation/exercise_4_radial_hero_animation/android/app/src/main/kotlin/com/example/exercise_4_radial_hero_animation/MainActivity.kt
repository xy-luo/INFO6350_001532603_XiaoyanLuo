package com.example.exercise_4_radial_hero_animation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
