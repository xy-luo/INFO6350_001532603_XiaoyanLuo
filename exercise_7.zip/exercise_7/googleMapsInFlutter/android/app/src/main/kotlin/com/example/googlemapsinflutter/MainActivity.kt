package com.example.googlemapsinflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
