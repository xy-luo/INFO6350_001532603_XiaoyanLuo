package com.example.exercise5takepic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
